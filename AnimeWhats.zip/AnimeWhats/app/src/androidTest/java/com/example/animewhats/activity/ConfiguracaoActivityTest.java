package com.example.animewhats.activity;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.intent.Intents;
import androidx.test.espresso.intent.matcher.IntentMatchers;
import androidx.test.rule.ActivityTestRule;

import com.example.animewhats.R;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withContentDescription;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.*;

public class ConfiguracaoActivityTest {

    @Rule
    public ActivityTestRule<ConfiguracaoActivity> configActivity = new ActivityTestRule<ConfiguracaoActivity>(ConfiguracaoActivity.class);

    @Before
    public void setUp() throws Exception {

        Intents.init();

    }

    @Test
    public void checkName(){

        String nome = "Mergulhão";

        //Checar se o campo de texto do nome está com o texto definido na variável "nome"
        Espresso.onView(withId(R.id.alterarNome)).check(matches(withText(nome)));

    }

    @Test
    public void clickBack(){

        //Clica no botão de voltar
        Espresso.onView(withContentDescription(R.string.abc_action_bar_up_description)).perform(click());

    }

    @After
    public void tearDown() throws Exception {

        Intents.release();

    }
}