package com.example.animewhats.activity;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.intent.Intents;
import androidx.test.espresso.intent.matcher.IntentMatchers;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.rule.ActivityTestRule;

import com.example.animewhats.R;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static androidx.test.espresso.Espresso.openActionBarOverflowOrOptionsMenu;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.AnyOf.anyOf;
import static org.junit.Assert.*;

public class AfterLoginActivityTest {

    @Rule
    public ActivityTestRule<AfterLoginActivity> alActivity = new ActivityTestRule<AfterLoginActivity>(AfterLoginActivity.class);

    @Before
    public void setUp() throws Exception {

        Intents.init();

    }

    @Test
    public void testSair(){

        //Abre o menu
        openActionBarOverflowOrOptionsMenu(InstrumentationRegistry.getInstrumentation().getTargetContext());

        //Clica na opção "Sair"
        Espresso.onView(anyOf(withText("Sair"), withId(R.id.sair_item))).perform(click());

    }

    @Test
    public void testConfig(){

        //Abre o menu
        openActionBarOverflowOrOptionsMenu(InstrumentationRegistry.getInstrumentation().getTargetContext());

        //Clica na opção "Configurações"
        Espresso.onView(anyOf(withText("Configurações"), withId(R.id.config_item))).perform(click());

        //Checa se a activity aberta é a "ConfiguracaoActivity" (Aqui não precisou usar o Thread.sleep)

        Intents.intended(IntentMatchers.hasComponent(ConfiguracaoActivity.class.getName()));

    }

    @After
    public void tearDown() throws Exception {

        Intents.release();

    }
}