package com.example.animewhats.activity;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.intent.Intents;
import androidx.test.espresso.intent.matcher.IntentMatchers;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.rule.ActivityTestRule;

import com.example.animewhats.R;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.Espresso.openActionBarOverflowOrOptionsMenu;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.withContentDescription;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.AnyOf.anyOf;
import static org.junit.Assert.*;

public class AfterLoginActivityTest {

    @Rule
    public ActivityTestRule<AfterLoginActivity> alActivity = new ActivityTestRule<AfterLoginActivity>(AfterLoginActivity.class);

    @Before
    public void setUp() throws Exception {

        Intents.init();

    }

    @Test
    public void testSair(){

        //Abre o menu
        openActionBarOverflowOrOptionsMenu(InstrumentationRegistry.getInstrumentation().getTargetContext());

        //Clica na opção "Sair"
        Espresso.onView(anyOf(withText("Sair"), withId(R.id.sair_item))).perform(click());

    }

    @Test
    public void testConfig(){

        //Abre o menu
        openActionBarOverflowOrOptionsMenu(InstrumentationRegistry.getInstrumentation().getTargetContext());

        //Clica na opção "Configurações"
        Espresso.onView(anyOf(withText("Configurações"), withId(R.id.config_item))).perform(click());

        //Checa se a activity aberta é a "ConfiguracaoActivity" (Aqui não precisou usar o Thread.sleep)
        Intents.intended(IntentMatchers.hasComponent(ConfiguracaoActivity.class.getName()));

    }

    @Test
    public void irAConfigEDepoisVoltar(){

        //Abre o menu
        openActionBarOverflowOrOptionsMenu(InstrumentationRegistry.getInstrumentation().getTargetContext());

        //Clica na opção "Configurações"
        Espresso.onView(anyOf(withText("Configurações"), withId(R.id.config_item))).perform(click());

        //Checa se a activity aberta é a "ConfiguracaoActivity" (Aqui não precisou usar o Thread.sleep)
        Intents.intended(IntentMatchers.hasComponent(ConfiguracaoActivity.class.getName()));

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Clica no botão de voltar
        Espresso.onView(withContentDescription(R.string.abc_action_bar_up_description)).perform(click());

    }

    @Test
    public void mostrarContatos(){

        //Clicar na tab "Contatos"
        Espresso.onView(withText("Contatos")).perform(click());

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void MudeNomeParaMergsEDepoisParaMergulhao(){

        //MERGS

        //Abre o menu
        openActionBarOverflowOrOptionsMenu(InstrumentationRegistry.getInstrumentation().getTargetContext());

        //Clica na opção "Configurações"
        Espresso.onView(anyOf(withText("Configurações"), withId(R.id.config_item))).perform(click());

        //Apaga o texto que estava digitado no campo de alterar nome
        Espresso.onView(withId(R.id.alterarNome)).perform(clearText());

        //Digita Mergs lugar
        Espresso.onView(withId(R.id.alterarNome)).perform(typeText("Mergs"));

        //Esperar um pouco
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Clica no botão de caneta
        Espresso.onView(withId(R.id.canetaRosa)).perform(click());

        //Clica no botão de voltar
        Espresso.onView(withContentDescription(R.string.abc_action_bar_up_description)).perform(click());

        //Clicar na tab "Contatos"
        Espresso.onView(withText("Contatos")).perform(click());

        //Esperar um pouco
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //MERGULHÃO

        //Abre o menu
        openActionBarOverflowOrOptionsMenu(InstrumentationRegistry.getInstrumentation().getTargetContext());

        //Clica na opção "Configurações"
        Espresso.onView(anyOf(withText("Configurações"), withId(R.id.config_item))).perform(click());

        //Apaga o texto que estava digitado no campo de alterar nome
        Espresso.onView(withId(R.id.alterarNome)).perform(clearText());

        //Coloque diretamente "Mergulhão" lugar
        Espresso.onView(withId(R.id.alterarNome)).perform(replaceText("Mergulhão"));

        //Esperar um pouco
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Clica no botão de caneta
        Espresso.onView(withId(R.id.canetaRosa)).perform(click());

        //Clica no botão de voltar
        Espresso.onView(withContentDescription(R.string.abc_action_bar_up_description)).perform(click());

        //Clicar na tab "Contatos"
        Espresso.onView(withText("Contatos")).perform(click());

        //Esperar um pouco
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @After
    public void tearDown() throws Exception {

        Intents.release();

    }
}