package com.example.animewhats.activity;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.IdlingRegistry;
import androidx.test.espresso.intent.Intents;
import androidx.test.espresso.intent.matcher.IntentMatchers;
import androidx.test.espresso.intent.rule.IntentsTestRule;
import androidx.test.rule.ActivityTestRule;

import com.example.animewhats.R;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static androidx.test.InstrumentationRegistry.getTargetContext;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.junit.Assert.*;

public class LoginActivityTest {

    @Rule
    public ActivityTestRule<LoginActivity> lActivityTestRule = new ActivityTestRule<LoginActivity>(LoginActivity.class);

    private String testEmail = "gui.mergulhao55@outlook.com";
    private String testSenha = "123456";

    @Before
    public void setUp() throws Exception {

        Intents.init();

    }

    @Test
    public void testInput(){

        // No campo de texto com o id "enterEmail" -> Faça um teste do usuário escrevendo
        // o valor da variável "testEmail" nele
        Espresso.onView(withId(R.id.enterEmail)).perform(typeText(testEmail));

        // Fecha o teclado
        Espresso.closeSoftKeyboard();

        // No campo de texto com o id "enterSenha" -> Faça um teste do usuário escrevendo
        // o valor da variável "testSenha" nele
        Espresso.onView(withId(R.id.enterSenha)).perform(typeText(testSenha));

        Espresso.closeSoftKeyboard();
        // No botão com o id de "btnLogin" -> Faça um teste de um usuário "apertando" ele
        Espresso.onView(withId(R.id.btnLogin)).perform(click());

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Intents.intended(IntentMatchers.hasComponent(AfterLoginActivity.class.getName()));

    }

    @After
    public void tearDown() throws Exception {

        Intents.release();

    }
}