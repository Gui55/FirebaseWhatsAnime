package com.example.animewhats.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.animewhats.R;
import com.example.animewhats.config.ConfiguracaoFirebase;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    private EditText campoEmail, campoSenha;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        firebaseAuth = ConfiguracaoFirebase.getFirebaseAuth();

        campoEmail = (EditText)findViewById(R.id.enterEmail);
        campoSenha = (EditText)findViewById(R.id.enterSenha);

    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser usuarioAtual = firebaseAuth.getCurrentUser();
        if(usuarioAtual != null){

            startActivity(new Intent(getApplicationContext(), AfterLoginActivity.class));

        }
    }

    public void irAoCadastro(View view) {

        startActivity(new Intent(getApplicationContext(), CadastroActivity.class));

    }

    public void logarUsuario(View view) {

        String email = campoEmail.getText().toString();
        String senha = campoSenha.getText().toString();

        if(email.isEmpty()){

            Toast.makeText(getApplicationContext(), "Digite o e-mail!", Toast.LENGTH_SHORT).show();

        } else {

            if(senha.isEmpty()){

                Toast.makeText(getApplicationContext(), "Digite a senha", Toast.LENGTH_SHORT).show();

            } else {

                firebaseAuth.signInWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if(task.isSuccessful()){

                            startActivity(new Intent(getApplicationContext(), AfterLoginActivity.class));

                        } else {

                            Toast.makeText(getApplicationContext(), "Erro", Toast.LENGTH_SHORT).show();

                        }

                    }
                });

            }

        }

    }
}
