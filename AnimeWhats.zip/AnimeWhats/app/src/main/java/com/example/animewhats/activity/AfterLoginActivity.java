package com.example.animewhats.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.example.animewhats.R;
import com.example.animewhats.config.ConfiguracaoFirebase;
import com.google.firebase.auth.FirebaseAuth;

public class AfterLoginActivity extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_after_login);

        firebaseAuth = ConfiguracaoFirebase.getFirebaseAuth();

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Cute Messaging");
        setSupportActionBar(toolbar);

        //Muda a cor dos 3 pontinhos do menu
        toolbar.getOverflowIcon().setColorFilter(getResources().getColor(R.color.tabWord), PorterDuff.Mode.SRC_ATOP);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.after_login_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){

            case R.id.sair_item:

                deslogarUsuario();
                finish();

                break;

        }

        return super.onOptionsItemSelected(item);
    }

    private void deslogarUsuario() {

        try{

            firebaseAuth.signOut();

        }catch (Exception e){

            e.printStackTrace();

        }

    }
}
