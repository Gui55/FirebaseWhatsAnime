package com.example.animewhats.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.animewhats.R;
import com.example.animewhats.config.ConfiguracaoFirebase;
import com.example.animewhats.model.Usuario;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;

public class CadastroActivity extends AppCompatActivity {

    private EditText campoNome, campoEmail, campoSenha, campoConfSenha;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        campoNome = (EditText)findViewById(R.id.cadastroNome);
        campoEmail = (EditText)findViewById(R.id.cadastroEmail);
        campoSenha = (EditText)findViewById(R.id.cadastroSenha);
        campoConfSenha = (EditText)findViewById(R.id.confSenha);

    }

    public void voltarLogin(View view) {

        startActivity(new Intent(getApplicationContext(), LoginActivity.class));

    }

    public void cadastrarUsuario(Usuario usuario){

        auth = ConfiguracaoFirebase.getFirebaseAuth();
        auth.createUserWithEmailAndPassword(

                usuario.getEmail(),
                usuario.getSenha()

        ).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()){

                    Toast.makeText(getApplicationContext(), "Sucesso", Toast.LENGTH_SHORT).show();

                    startActivity(new Intent(getApplicationContext(), LoginActivity.class));

                    finish();

                } else {

                    String excecao = "";

                    try{

                        throw task.getException();

                    }catch(FirebaseAuthWeakPasswordException e){

                        excecao = "Digite uma senha mais forte!";

                    }catch(FirebaseAuthInvalidCredentialsException e){

                        excecao = "Credenciais Inválidas!";

                    }catch(FirebaseAuthUserCollisionException e){

                        excecao = "Já existe um usuário com essas credenciais!";

                    }catch(Exception e){

                        e.printStackTrace();
                        excecao = "Erro";

                    }

                    Toast.makeText(getApplicationContext(), excecao, Toast.LENGTH_SHORT).show();

                }

            }
        });

    }

    public void verificarCampos(View view) {

        String nome = campoNome.getText().toString();
        String email = campoEmail.getText().toString();
        String senha = campoSenha.getText().toString();
        String confSenha = campoConfSenha.getText().toString();

        if(nome.isEmpty()){

            Toast.makeText(getApplicationContext(), "O nome está vazio!", Toast.LENGTH_SHORT).show();

        } else {

            if(email.isEmpty()){

                Toast.makeText(getApplicationContext(), "O e-mail está vazio!", Toast.LENGTH_SHORT).show();

            } else {

                if(senha.isEmpty()){

                    Toast.makeText(getApplicationContext(), "Crie uma senha!", Toast.LENGTH_SHORT).show();

                } else {

                    if(confSenha.isEmpty() || !confSenha.equals(senha)){

                        Toast.makeText(getApplicationContext(), "Confirme sua senha direito!", Toast.LENGTH_SHORT).show();

                    } else {

                        Usuario usuario = new Usuario();

                        usuario.setNome(nome);
                        usuario.setEmail(email);
                        usuario.setSenha(senha);

                        cadastrarUsuario(usuario);

                    }

                }

            }

        }

    }
}
