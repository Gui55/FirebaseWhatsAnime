package com.example.animewhats.helper;

import android.util.Base64;

public class Base64Custom {

    public static String encodeBase64(String txt){

        return Base64.encodeToString(txt.getBytes(), Base64.DEFAULT).replaceAll("(\\n|\\r)", "");

    }

    public static String decodeBase64(String txt){

        return new String(Base64.decode(txt, Base64.DEFAULT));

    }

}
