package com.example.animewhats.helper;

import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.animewhats.config.ConfiguracaoFirebase;
import com.example.animewhats.model.Usuario;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

public class UsuarioFirebase {

    public static String getIdentification(){

        FirebaseAuth user = ConfiguracaoFirebase.getFirebaseAuth();
        String email = user.getCurrentUser().getEmail();
        String identificadorUsuario = Base64Custom.encodeBase64(email);

        return identificadorUsuario;

    }

    public static FirebaseUser getUsuarioAtual(){

        FirebaseAuth user = ConfiguracaoFirebase.getFirebaseAuth();

        return user.getCurrentUser();

    }

    public static boolean atualizarNome(String nome){

        try {

            FirebaseUser firebaseUser = getUsuarioAtual();

            UserProfileChangeRequest userProfileChangeRequest = new UserProfileChangeRequest.Builder()
                    .setDisplayName(nome)
                    .build();

            firebaseUser.updateProfile(userProfileChangeRequest).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {

                    if(!task.isSuccessful()){
                        Log.d("ErroProfile", "Erro ao atualizar nome do perfil");
                    }

                }
            });

            return true;

        }catch (Exception e){
            e.printStackTrace();
            return false;
        }

    }

    public static boolean atualizarFoto(Uri uri){

        try {

            FirebaseUser firebaseUser = getUsuarioAtual();

            UserProfileChangeRequest userProfileChangeRequest = new UserProfileChangeRequest.Builder()
                    .setPhotoUri(uri)
                    .build();

            firebaseUser.updateProfile(userProfileChangeRequest).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {

                    if(!task.isSuccessful()){
                        Log.d("ErroProfile", "Erro ao atualizar foto do perfil");
                    }

                }
            });

            return true;

        }catch (Exception e){
            e.printStackTrace();
            return false;
        }

    }

    public static Usuario getDadosUserLogado(){

        FirebaseUser firebaseUser = getUsuarioAtual();

        Usuario user = new Usuario();
        user.setEmail(firebaseUser.getEmail());
        user.setNome(firebaseUser.getDisplayName());

        if(firebaseUser.getPhotoUrl()==null){
            user.setFoto("");
        }else {

            user.setFoto(firebaseUser.getPhotoUrl().toString());

        }

        return user;

    }

}
