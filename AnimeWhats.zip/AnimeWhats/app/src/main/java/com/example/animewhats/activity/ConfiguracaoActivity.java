package com.example.animewhats.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.animewhats.R;
import com.example.animewhats.config.ConfiguracaoFirebase;
import com.example.animewhats.helper.UsuarioFirebase;
import com.example.animewhats.helper.Permissao;
import com.example.animewhats.model.Usuario;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;

import de.hdodenhof.circleimageview.CircleImageView;

public class ConfiguracaoActivity extends AppCompatActivity {

    private static final int TAKE_PHOTO = 50, GET_IMAGE = 51;
    private CircleImageView circleImageView;
    private StorageReference storageReference;
    private String identificadorUsuario;
    private ProgressBar progressBar;
    private EditText editNome;
    private Usuario usuarioLogado;

    private String[] permissoesNecessarias = new String[]{
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuracao);

        editNome = (EditText)findViewById(R.id.alterarNome);

        progressBar = (ProgressBar)findViewById(R.id.progressConfig);
        progressBar.getIndeterminateDrawable().setColorFilter(getResources().getColor(R.color.tabWord),
                android.graphics.PorterDuff.Mode.MULTIPLY);

        storageReference = ConfiguracaoFirebase.getStorageReference();
        identificadorUsuario = UsuarioFirebase.getIdentification();
        usuarioLogado = UsuarioFirebase.getDadosUserLogado();

        circleImageView = findViewById(R.id.circleProfilePic);

        Permissao.validarPermissoes(permissoesNecessarias, this, 1);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Configurações");
        setSupportActionBar(toolbar);

        //Muda a cor dos 3 pontinhos do menu
        toolbar.getOverflowIcon().setColorFilter(getResources().getColor(R.color.tabWord), PorterDuff.Mode.SRC_ATOP);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setHomeAsUpIndicator(R.drawable.voltar_icon);

        //Pega o usuário atual
        FirebaseUser firebaseUser = UsuarioFirebase.getUsuarioAtual();

        //Pega a uri da foto de perfil do usuário atual
        Uri uri = firebaseUser.getPhotoUrl();

        //Se a imagem do usuário atual tiver uma uri, ela será carregada. Caso contrário,
        //a imagem padrão será carregada no lugar
        if(uri!=null){

            Glide.with(ConfiguracaoActivity.this).load(uri).into(circleImageView);

        } else {
            circleImageView.setImageResource(R.drawable.moe_girl);
        }

        editNome.setText(firebaseUser.getDisplayName());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        for(int permissaoResultado : grantResults){

            if(permissaoResultado == PackageManager.PERMISSION_DENIED){
                alertaValidacaoPermissao();
            }

        }
    }

    private void alertaValidacaoPermissao() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Permissões negadas");
        builder.setMessage("Para utilizar o app é necessário aceitar estas permissões");
        builder.setCancelable(false);
        builder.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();

    }

    public void tirarFoto(View view) {

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if(intent.resolveActivity(getPackageManager()) != null){

            startActivityForResult(intent, TAKE_PHOTO);

        }

    }

    public void selecionarImagem(View view) {

        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);

        if(intent.resolveActivity(getPackageManager()) != null){

            startActivityForResult(intent, GET_IMAGE);

        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Bitmap imagem = null;

        if(resultCode == RESULT_OK){

            try{

                switch (requestCode){

                    case TAKE_PHOTO:
                        imagem = (Bitmap)data.getExtras().get("data");
                        break;

                    case GET_IMAGE:
                        Uri imLocal = data.getData();

                        if(Build.VERSION.SDK_INT < 28){

                            imagem = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imLocal);

                        } else {

                            ImageDecoder.Source source = ImageDecoder.createSource(this.getContentResolver(), imLocal);
                            imagem = ImageDecoder.decodeBitmap(source);
                        }

                        break;

                }

            }catch (Exception e){
                e.printStackTrace();
            }

            if(imagem!=null){
                circleImageView.setImageBitmap(imagem);

                //Recuperar dados da imagem
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                imagem.compress(Bitmap.CompressFormat.JPEG, 70, byteArrayOutputStream);
                byte[] dadosImagem = byteArrayOutputStream.toByteArray();

                //Salvar imagem
                StorageReference imageRef =
                        storageReference.child("imagens")
                        .child("perfil")
                        .child(identificadorUsuario+"jpeg");

                UploadTask uploadTask = imageRef.putBytes(dadosImagem);

                progressBar.setVisibility(ProgressBar.VISIBLE);

                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        progressBar.setVisibility(ProgressBar.INVISIBLE);

                        Toast.makeText(ConfiguracaoActivity.this, "Erro ao fazer upload de imagem", Toast.LENGTH_SHORT).show();

                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                        progressBar.setVisibility(ProgressBar.INVISIBLE);

                        Toast.makeText(ConfiguracaoActivity.this, "Sucesso ao fazer upload de imagem", Toast.LENGTH_SHORT).show();

                        Task<Uri> result = taskSnapshot.getStorage().getDownloadUrl();
                        result.addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                atualizarFotoUsuario(uri);
                            }
                        });
                    }
                });
            }

        }

    }

    private void atualizarFotoUsuario(Uri uri) {

        boolean retorno = UsuarioFirebase.atualizarFoto(uri);

        if(retorno){
            usuarioLogado.setFoto(uri.toString());
            usuarioLogado.atualizar();

            Toast.makeText(getApplicationContext(), "Foto atualizada com sucesso!", Toast.LENGTH_SHORT).show();
        }

    }

    public void salvarNome(View view) {

        String nome = editNome.getText().toString();

        boolean retorno = UsuarioFirebase.atualizarNome(nome);

        if(retorno){

            usuarioLogado.setNome(nome);
            usuarioLogado.atualizar();

            Toast.makeText(getApplicationContext(), "Nome alterado com sucesso!", Toast.LENGTH_SHORT).show();

        }

    }
}
