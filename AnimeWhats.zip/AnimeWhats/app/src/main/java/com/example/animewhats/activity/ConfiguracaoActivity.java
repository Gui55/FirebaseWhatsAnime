package com.example.animewhats.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;

import com.example.animewhats.R;
import com.example.animewhats.helper.Permissao;

import de.hdodenhof.circleimageview.CircleImageView;

public class ConfiguracaoActivity extends AppCompatActivity {

    private static final int TAKE_PHOTO = 50, GET_IMAGE = 51;
    private CircleImageView circleImageView;

    private String[] permissoesNecessarias = new String[]{
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuracao);

        circleImageView = findViewById(R.id.circleProfilePic);

        Permissao.validarPermissoes(permissoesNecessarias, this, 1);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Configurações");
        setSupportActionBar(toolbar);

        //Muda a cor dos 3 pontinhos do menu
        toolbar.getOverflowIcon().setColorFilter(getResources().getColor(R.color.tabWord), PorterDuff.Mode.SRC_ATOP);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setHomeAsUpIndicator(R.drawable.voltar_icon);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        for(int permissaoResultado : grantResults){

            if(permissaoResultado == PackageManager.PERMISSION_DENIED){
                alertaValidacaoPermissao();
            }

        }
    }

    private void alertaValidacaoPermissao() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Permissões negadas");
        builder.setMessage("Para utilizar o app é necessário aceitar estas permissões");
        builder.setCancelable(false);
        builder.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();

    }

    public void tirarFoto(View view) {

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if(intent.resolveActivity(getPackageManager()) != null){

            startActivityForResult(intent, TAKE_PHOTO);

        }

    }

    public void selecionarImagem(View view) {

        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);

        if(intent.resolveActivity(getPackageManager()) != null){

            startActivityForResult(intent, GET_IMAGE);

        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Bitmap imagem = null;

        if(resultCode == RESULT_OK){

            try{

                switch (requestCode){

                    case TAKE_PHOTO:
                        imagem = (Bitmap)data.getExtras().get("data");
                        break;

                    case GET_IMAGE:
                        Uri imLocal = data.getData();

                        if(Build.VERSION.SDK_INT < 28){

                            imagem = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imLocal);

                        } else {

                            ImageDecoder.Source source = ImageDecoder.createSource(this.getContentResolver(), imLocal);
                            imagem = ImageDecoder.decodeBitmap(source);
                        }

                        break;

                }

            }catch (Exception e){
                e.printStackTrace();
            }

            if(imagem!=null){
                circleImageView.setImageBitmap(imagem);
            }

        }

    }
}
