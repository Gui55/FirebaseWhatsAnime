package com.example.animewhats.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.animewhats.R;
import com.example.animewhats.model.Usuario;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ContatosAdapter extends RecyclerView.Adapter<ContatosAdapter.ContatosViewHolder> {

    private List<Usuario> contatos;
    private Context context;

    public ContatosAdapter(List<Usuario> contatos, Context context){
        this.contatos = contatos;
        this.context = context;
    }

    @NonNull
    @Override
    public ContatosViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemLista = LayoutInflater.from(parent.getContext()).inflate(R.layout.contatos_linha, parent, false);
        return new ContatosViewHolder(itemLista);
    }

    @Override
    public void onBindViewHolder(@NonNull ContatosViewHolder holder, int position) {

        Usuario usuario = contatos.get(position);

        if(usuario.getFoto()!=null){
            Uri uri = Uri.parse(usuario.getFoto());
            Glide.with(context).load(uri).into(holder.foto);
        } else {
            holder.foto.setImageResource(R.drawable.moe_girl);
        }

        holder.nome.setText(usuario.getNome());
        holder.email.setText(usuario.getEmail());
    }

    @Override
    public int getItemCount() {
        return contatos.size();
    }

    public class ContatosViewHolder extends RecyclerView.ViewHolder{

        CircleImageView foto;
        TextView nome, email;

        public ContatosViewHolder(@NonNull View itemView) {
            super(itemView);

            foto = itemView.findViewById(R.id.fotoPerfil);
            nome = itemView.findViewById(R.id.textNome);
            email = itemView.findViewById(R.id.textEmail);
        }
    }

}
